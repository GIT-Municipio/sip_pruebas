<pre><xmp>
<?php
	var_dump($_POST);
?></xmp></pre>